import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

public class teacherGUI {
    private ArrayList<Teacher> teachers = new ArrayList<>();

    public void GUI() {

        JFrame frame = new JFrame("Coursework GUI");
        frame.setVisible(true);
        frame.setSize(700, 700);
        frame.setLayout(null);

        // FOR LECTURER
        JLabel lec = new JLabel("Lecturer");
        lec.setBounds(700, 10, 200, 130);
        lec.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        frame.add(lec);

        JLabel TeaIDa = new JLabel("Teacher ID:");
        TeaIDa.setBounds(30, 150, 100, 50);
        frame.add(TeaIDa);

        JTextField TeaIDa1 = new JTextField();
        TeaIDa1.setBounds(175, 160, 100, 30);
        frame.add(TeaIDa1);

        JLabel TeaNa = new JLabel("Teacher Name:");
        TeaNa.setBounds(30, 200, 100, 50);
        frame.add(TeaNa);

        JTextField TeaNa1 = new JTextField();
        TeaNa1.setBounds(175, 210, 100, 30);
        frame.add(TeaNa1);

        JLabel TeaADDa = new JLabel("Teacher Address:");
        TeaADDa.setBounds(30, 250, 100, 50);
        frame.add(TeaADDa);

        JTextField TeaADDa1 = new JTextField();
        TeaADDa1.setBounds(175, 260, 100, 30);
        frame.add(TeaADDa1);

        JLabel YOEa = new JLabel("Years of Experience:");
        YOEa.setBounds(30, 300, 150, 50);
        frame.add(YOEa);

        JTextField YOEa1 = new JTextField();
        YOEa1.setBounds(175, 310, 100, 30);
        frame.add(YOEa1);

        JLabel WorTa = new JLabel("Working Type:");
        WorTa.setBounds(1250, 150, 100, 50);
        frame.add(WorTa);

        JTextField WorTa1 = new JTextField();
        WorTa1.setBounds(1400, 160, 100, 30);
        frame.add(WorTa1);

        JLabel EmpSa = new JLabel("Employment Status:");
        EmpSa.setBounds(1250, 200, 150, 50);
        frame.add(EmpSa);

        JTextField EmpSa1 = new JTextField();
        EmpSa1.setBounds(1400, 210, 100, 30);
        frame.add(EmpSa1);

        JLabel GraSa = new JLabel("Graded Score:");
        GraSa.setBounds(1250, 250, 100, 50);
        frame.add(GraSa);

        JTextField GraSa1 = new JTextField();
        GraSa1.setBounds(1400, 260, 100, 30);
        frame.add(GraSa1);

        JLabel Depa = new JLabel("Department:");
        Depa.setBounds(1250, 300, 100, 50);
        frame.add(Depa);

        JTextField Depa1 = new JTextField();
        Depa1.setBounds(1400, 310, 100, 30);
        frame.add(Depa1);

        JButton disa = new JButton("Display");
        disa.setBounds(450, 200, 100, 30);
        disa.setBackground(new Color(135, 206, 235));
        frame.add(disa);

        JButton clea = new JButton("Clear");
        clea.setBounds(450, 250, 100, 30);
        clea.setBackground(Color.RED);
        frame.add(clea);

        JButton AddLa = new JButton("Add Lecturer");
        AddLa.setBounds(900, 200, 150, 30);
        AddLa.setBackground(Color.GREEN);
        frame.add(AddLa);

        JButton GraAa = new JButton("Grade Assignments");
        GraAa.setBounds(900, 250, 150, 30);
        GraAa.setBackground(Color.GREEN);
        frame.add(GraAa);

        // FOR TUTOR
        JLabel Tut = new JLabel("Tutor");
        Tut.setBounds(700, 350, 200, 130);
        Tut.setFont(new Font("Times New Roman", Font.PLAIN, 30));
        frame.add(Tut);

        JLabel TeaIDb = new JLabel("Teacher ID:");
        TeaIDb.setBounds(30, 500, 100, 50);
        frame.add(TeaIDb);

        JTextField TeaIDb1 = new JTextField();
        TeaIDb1.setBounds(200, 510, 100, 30);
        frame.add(TeaIDb1);

        JLabel TeaNb = new JLabel("Teacher Name:");
        TeaNb.setBounds(30, 550, 100, 50);
        frame.add(TeaNb);

        JTextField TeaNb1 = new JTextField();
        TeaNb1.setBounds(200, 560, 100, 30);
        frame.add(TeaNb1);

        JLabel TeaAb = new JLabel("Teacher Address:");
        TeaAb.setBounds(30, 600, 100, 50);
        frame.add(TeaAb);

        JTextField TeaAb1 = new JTextField();
        TeaAb1.setBounds(200, 610, 100, 30);
        frame.add(TeaAb1);

        JLabel AcaQa = new JLabel("Academic Qualifications:");
        AcaQa.setBounds(30, 650, 150, 50);
        frame.add(AcaQa);

        JTextField AcaQa1 = new JTextField();
        AcaQa1.setBounds(200, 660, 100, 30);
        frame.add(AcaQa1);

        JLabel PerIa = new JLabel("Perfomance Index:");
        PerIa.setBounds(30, 700, 150, 50);
        frame.add(PerIa);

        JTextField PerIa1 = new JTextField();
        PerIa1.setBounds(200, 710, 100, 30);
        frame.add(PerIa1);

        JLabel NeSala = new JLabel("New Salary:");
        NeSala.setBounds(30, 750, 150, 50);
        frame.add(NeSala);

        JTextField NeSala1 = new JTextField();
        NeSala1.setBounds(200, 760, 100, 30);
        frame.add(NeSala1);

        JLabel Spea = new JLabel("Specialization:");
        Spea.setBounds(1250, 500, 150, 50);
        frame.add(Spea);

        JTextField Spea1 = new JTextField();
        Spea1.setBounds(1400, 510, 100, 30);
        frame.add(Spea1);

        JLabel WTa = new JLabel("Working Type:");
        WTa.setBounds(1250, 550, 100, 50);
        frame.add(WTa);

        JTextField WTa1 = new JTextField();
        WTa1.setBounds(1400, 560, 100, 30);
        frame.add(WTa1);

        JLabel EmpSb = new JLabel("Employment Status:");
        EmpSb.setBounds(1250, 600, 150, 50);
        frame.add(EmpSb);

        JTextField EmpSb1 = new JTextField();
        EmpSb1.setBounds(1400, 610, 100, 30);
        frame.add(EmpSb1);

        JLabel WorHa = new JLabel("Working Hours:");
        WorHa.setBounds(1250, 650, 100, 50);
        frame.add(WorHa);

        JTextField WorHa1 = new JTextField();
        WorHa1.setBounds(1400, 660, 100, 30);
        frame.add(WorHa1);

        JLabel Salb = new JLabel("Salary:");
        Salb.setBounds(1250, 700, 100, 50);
        frame.add(Salb);

        JTextField Salb1 = new JTextField();
        Salb1.setBounds(1400, 710, 100, 30);
        frame.add(Salb1);

        JLabel NPIa = new JLabel("New Perfomance Index:");
        NPIa.setBounds(1250, 750, 150, 50);
        frame.add(NPIa);

        JTextField NPI1 = new JTextField();
        NPI1.setBounds(1400, 760, 100, 30);
        frame.add(NPI1);

        JButton Disb = new JButton("Display");
        Disb.setBounds(450, 550, 100, 30);
        Disb.setBackground(new Color(135, 206, 235));
        frame.add(Disb);

        JButton Cleb = new JButton("Clear");
        Cleb.setBounds(450, 650, 100, 30);
        Cleb.setBackground(Color.RED);
        frame.add(Cleb);

        JButton AddTa = new JButton("Add Tutor");
        AddTa.setBounds(950, 550, 120, 30);
        AddTa.setBackground(Color.GREEN);
        frame.add(AddTa);

        JButton RemTa = new JButton("Remove Tutor");
        RemTa.setBounds(950, 600, 120, 30);
        RemTa.setBackground(Color.RED);
        frame.add(RemTa);

        JButton SetSa = new JButton("Set Salary");
        SetSa.setBounds(950, 650, 120, 30);
        SetSa.setBackground(Color.GREEN);
        frame.add(SetSa);

        AddLa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                try {
                    if (TeaIDa1.getText().isEmpty() || TeaNa1.getText().isEmpty() || TeaADDa1.getText().isEmpty() || YOEa1.getText().isEmpty() || WorTa1.getText().isEmpty() || EmpSa1.getText().isEmpty() || GraSa1.getText().isEmpty() || Depa1.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Fill all the fields please!");
                    } else {
                        Lecturer l = new Lecturer(Integer.parseInt(TeaIDa1.getText()), TeaNa1.getText(), TeaADDa1.getText(), WorTa1.getText(), EmpSa1.getText(), Depa1.getText(), Integer.parseInt(YOEa1.getText()), Integer.parseInt(GraSa1.getText()));
                        teachers.add(l);
                        JOptionPane.showMessageDialog(null, "Added to Lecturer");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Enter the valid values for integers type");
                }
            }
        });

        AddTa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                try {
                    if (TeaIDb1.getText().isEmpty() || TeaNb1.getText().isEmpty() || TeaAb1.getText().isEmpty() || AcaQa1.getText().isEmpty() || PerIa1.getText().isEmpty() || Salb1.getText().isEmpty() || Spea1.getText().isEmpty() || WTa1.getText().isEmpty() || EmpSb1.getText().isEmpty() || WorHa1.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Fill all the fields please!");
                    } else {
                        Tutor T = new Tutor(Integer.parseInt(TeaIDb1.getText()), TeaNb1.getText(), TeaAb1.getText(), WTa1.getText(), EmpSb1.getText(),Integer.parseInt( WorHa1.getText()) ,Double.parseDouble(Salb1.getText()), Spea1.getText(), AcaQa1.getText(), Integer.parseInt(PerIa1.getText()));
                        teachers.add(T);
                        JOptionPane.showMessageDialog(null, "Added to tutor");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Enter the valid values for integers type");
                }
            }
        });

        disa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                if (TeaIDa1.getText().isEmpty() || TeaNa1.getText().isEmpty() || TeaADDa1.getText().isEmpty() || YOEa1.getText().isEmpty() || WorTa1.getText().isEmpty() || EmpSa1.getText().isEmpty() || GraSa1.getText().isEmpty() || Depa1.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Fill all the fields please!");
                } else {
                    for (Teacher l : teachers) {
                        if (l instanceof Lecturer) {
                            l.display();
                        }
                    }
                }

            }
        });

        Disb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                if (TeaIDb1.getText().isEmpty() || TeaNb1.getText().isEmpty() || TeaAb1.getText().isEmpty() || AcaQa1.getText().isEmpty() || PerIa1.getText().isEmpty() || Salb1.getText().isEmpty() || Spea1.getText().isEmpty() || WTa1.getText().isEmpty() || EmpSb1.getText().isEmpty() || WorHa1.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Fill all the fields please!");
                } else {
                    for (Teacher T : teachers) {
                        if (T instanceof Tutor) {
                            T.display();
                        }
                    }
                }
            }
        });

        clea.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                TeaIDa1.setText("");
                TeaNa1.setText("");
                TeaADDa1.setText("");
                YOEa1.setText("");
                WorTa1.setText("");
                EmpSa1.setText("");
                GraSa1.setText("");
                Depa1.setText("");

            }
        });

        Cleb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                TeaIDb1.setText("");
                TeaNb1.setText("");
                TeaAb1.setText("");
                AcaQa1.setText("");
                PerIa1.setText("");
                Salb1.setText("");
                Spea1.setText("");
                WTa1.setText("");
                EmpSb1.setText("");
                WorHa1.setText("");

            }
        });

        GraAa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                try {
                    int teacherId = Integer.parseInt(TeaIDa1.getText());
                    int gradedScore = Integer.parseInt(GraSa1.getText());
                    String department = Depa1.getText();
                    int yearsOfExperience = Integer.parseInt(YOEa1.getText());

                    for (Teacher teacher : teachers) {
                        if (teacher instanceof Lecturer && teacher.getTeacherID() == teacherId) {
                            Lecturer lecturer = (Lecturer) teacher; // downcasting
                            String grade = lecturer.gradeAssignment(gradedScore, department, yearsOfExperience);
                            JOptionPane.showMessageDialog(frame, "Graded assignment result: " + grade);
                            return;
                        }
                    }

                    JOptionPane.showMessageDialog(frame, "Lecturer with ID " + teacherId + " not found!");

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter valid numeric values for Teacher ID, Graded Score, Years of Experience.");
                }
            }
        });

        RemTa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get input value from text field
                    int TeacherID = Integer.parseInt(TeaIDb1.getText());

                    // Find and remove the matching tutor
                    boolean removed = false;
                    for (Iterator<Teacher> iterator = teachers.iterator(); iterator.hasNext(); ) {
                        Teacher teacher = iterator.next();
                        if (teacher instanceof Tutor && teacher.getTeacherID() == TeacherID) {
                            iterator.remove();
                            removed = true;
                            // Display success message
                            JOptionPane.showMessageDialog(frame, "Tutor removed successfully!");
                            break;
                        }
                    }
                    // Display error message if tutor not found
                    if (!removed) {
                        JOptionPane.showMessageDialog(frame, "Tutor with ID " + TeacherID + " not found!");
                    }
                } catch (NumberFormatException ex) {
                    // Display error message for invalid input
                    JOptionPane.showMessageDialog(frame, "Only integers values is accepted for  Teacher ID.");
                }
            }
        });

       // ActionListener for Set Salary button
SetSa.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent ae) {
        try {
            if (TeaIDb1.getText().isEmpty() || PerIa1.getText().isEmpty() || NeSala1.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a valid ID, Performance Index, and New Salary.");
            } else {
                int tutorId = Integer.parseInt(TeaIDb1.getText());
                int newPerformanceIndex = Integer.parseInt(NPI1.getText());
                double newSalary = Double.parseDouble(NeSala1.getText());
                // Updating the tutor's salary and performance index
               for (Teacher teacher : teachers) {
                            if (teacher instanceof Tutor && teacher.getTeacherID() == tutorId) {
                                Tutor tutor = (Tutor) teacher;
                                String message = tutor.setSalary(newSalary, newPerformanceIndex);
                                JOptionPane.showMessageDialog(null, message);
                                break;
                            }
                        }
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Only integers values are accepted for ID, Performance Index, and New Salary.");
                }
            }
        });


    }

    public static void main(String[] args) {
        teacherGUI teacherGUI = new teacherGUI();
        teacherGUI.GUI();
    }
}
